<?php $__env->startSection('content'); ?>
    <div class="container">
        <form action="<?php echo e(route('profile_edit', $candidate->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
        <div style="text-align: center" class="profile-userpic">
            <img style="width: 19%;" src="<?php echo e(asset('images/'.$candidate->picture)); ?>" class="img-responsive" alt="">
            <br><br>
            <input type="file" style="padding-left: 100px;" name="image" class="btn-primary btn" >
            <br>
            <input style="border-color: black" class="form-control" type="text" value="<?php echo e($user_data->name); ?> " readonly><br><br>
            <textarea style="border-color: black" class="form-control" name="description" id="" cols="70" rows="4"><?php echo e($candidate->description); ?></textarea><br><br><br>
            <div style="border: 4px dashed #8e9cff;width: 100%;height: 100px;">
                <input  type="file" name="candidate_file"  />
            </div>
            <br><br>
            <button type="submit" class="btn btn-primary form-control">Edit</button>
        </div>
        </form>
        <?php if(strlen($files) > 2): ?>
            <center><h1 >Files</h1></center>
            <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><br>
                <form action="<?php echo e(route('delete_file', $item->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div>
                        <a style="font-size: 25px" href="<?php echo e(asset('candidate_files/'.$item->file_name)); ?>"><?php echo e(substr($item->file_name,11)); ?></a> <button type="submit" class="btn-danger btn " style="float: right">X</button>
                        <br>
                    </div>
                </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\election\resources\views/candidate/profile.blade.php ENDPATH**/ ?>