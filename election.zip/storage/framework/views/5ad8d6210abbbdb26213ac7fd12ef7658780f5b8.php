<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role==1): ?>
        <div  style="background-color:wheat;width:50%;height: 50%; padding: 15px;" >
            <form action="<?php echo e(route('create_election')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="text" class="form-control" name="name" placeholder="Name...">
                <br><br>
                <input type="date" class="form-control" name="date" placeholder="Date...">
                <br>
                <button class="btn btn-primary">Create</button>
            </form>
        </div>
        <?php endif; ?>
    <br><br>
    <div>
        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_content">
                        <!-- start project list -->
                        <table class="table table-striped projects">
                            <thead>
                            <tr>
                                <th style="width: 10%">No</th>
                                <th style="width: 15%">Election Name</th>
                                <th style="width: 15%">Deadline</th>
                                <th style="width: 15%">Details</th>
                                <?php if(auth()->user()->role==1): ?><th style="width: 15%"><center>Delete</center></th><?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $elections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width: 10%"><?php echo e($key+1); ?></td>
                                    <td style="width: 15%">
                                        <a><?php echo e($item->name); ?></a>
                                    </td>
                                    <td style="width: 15%">
                                        <?php echo e(date("D", strtotime($item->deadline))); ?> <?php echo e(date("F", strtotime($item->deadline))); ?>  <?php echo e(date("Y", strtotime($item->deadline))); ?> 17:59
                                    </td>
                                    <td style="width: 15%">
                                        <?php if($item->deadline < Carbon\Carbon::now()): ?>
                                            <a  class="btn btn-primary" style="color:white" href="<?php echo e(route('details_of_election',$item->id)); ?>" ><i class="fa fa-sliders"></i> Statistics</a>
                                        <?php else: ?>
                                            <a  class="btn btn-success" style="color:white" href="<?php echo e(route('details',$item->id)); ?>" ><i class="fa fa-table"></i> Vote It!</a>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(auth()->user()->role==1): ?> <td style="width: 15%">
                                        <button class="btn btn-danger" style="color:white" data-toggle="modal" data-target="#exampleModal<?php echo e($item->id); ?>"><i class="fa fa-trash-o"></i> Delete</button>
                                    </td><?php endif; ?>
                                </tr>

                                <!-- Modal -->
                                <div class="modal fade" id="exampleModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <h5 class="container">Are you sure you want to delete election: <br><br><b>"<?php echo e($item->name); ?>" ?</b></h5>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-dismiss="modal">No</button>
                                                <button type="button" class="btn btn-success" > <a style="color:white;" href="">Yes</a></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <!-- end project list -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\election\resources\views/admin/calender_show.blade.php ENDPATH**/ ?>