<?php $__env->startSection('content'); ?>
        <div style="text-align: center" class="container">
            <span ><h2><b><?php echo e($election->name); ?></b></h2><br></span>
            <?php if($have_voted): ?>
                <div class="alert-success">Your vote get registered successfully!</div>
            <?php else: ?>
            <hr style="border-width: 10px"/>
        Candidates: <br>
            <form action="<?php echo e(route('vote',auth()->user()->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
            <div class="row">
                <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($candidate->election_id==$election->id): ?>
                        <?php echo csrf_field(); ?>
                        <?php if($key==3): ?></div><div class="row"><?php endif; ?>
                        <?php if($candidate->confirm==1): ?>
                        <div class="card col-sm" style="width: 18rem;">
                            <input type="hidden" name="election" value="<?php echo e($election->id); ?>">
                            <div style="height: 150px;"><center><img style="width: 120px;" src="<?php echo e(asset('images/'.$candidate->picture)); ?>" class="img-responsive" alt=""></center></div>
                            <br><br>
                            <div class="card-body">
                                <h5 class="card-title"> <?php echo e($candidate->user->name); ?></h5>
                                <h6 class="card-text"><?php echo e($candidate->description); ?></h6><br>
                                <?php $__currentLoopData = \App\Files::where('profile_file_id','=', $candidate->file_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(asset('candidate_files/'.$file->file_name)); ?>">
                                        <?php echo e(substr($file->file_name,11)); ?>

                                    </a><br>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <input class="form-control" type="radio" value="<?php echo e($candidate->id); ?>" name="vote">
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
                <br><br>
                <div style="text-align: center">
                    <input class="btn btn-primary" type="submit" value="Vote!">
                </div>
            </form>
                <?php endif; ?>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\election\resources\views/calendar/details.blade.php ENDPATH**/ ?>