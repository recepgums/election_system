<?php $__env->startSection('content'); ?>

    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $candidate_total_vote= \App\Votes::where('candidate_id','=',$candidate->id)->where('election_id',$election_id)->get()->count()?>
    <div class="row">
            <div style="height: 150px;">
                <center><img style="width: 60px; height: 80px;" src="<?php echo e(asset('images/'.$candidate->picture)); ?>" class="img-responsive" alt=""></center>
                <br>
                <h3 class=" text-center"> <?php echo e($candidate->user->name); ?></h3>
                <h5 class="text-center small">
                   Total Vote:  <?php echo e($candidate_total_vote); ?>

                </h5>
            </div>
            <div style="height: 20px;width: 75%;margin-left: 50px" class="">
                <br><br><br>
                <div style="background-color: <?php echo e($colors[$key]); ?>;height: 10px;width: <?php echo e($candidate_total_vote/$total_votes*100); ?>%"></div>
                <h5 class="float-right">
                    <?php echo e($candidate_total_vote/$total_votes*100); ?>%
                </h5>
            </div>
    </div>
        <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\election\resources\views/calendar/details_of_election.blade.php ENDPATH**/ ?>